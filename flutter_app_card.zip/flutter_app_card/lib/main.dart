import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black38,
        appBar: AppBar(
          backgroundColor: Colors.redAccent,
          title: Text('My Business Card'),
        ),
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Center(
                child: CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.redAccent,
                  backgroundImage: AssetImage('images/img1.png'),
                ),
              ),
              Text(
                'Pulkit Dikshit',
                style: TextStyle(
                  fontFamily: 'Pacifico',
                  fontSize: 20,
                  color: Colors.white70,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'FLUTTER DEVELOPER',
                style: TextStyle(
                  fontFamily: 'CourierPrime',
                  fontSize: 23,
                  color: Colors.white,
                  letterSpacing: 2,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                width: 120,
                child: Divider(color: Colors.tealAccent,),
              ),
              Card(
                color: Colors.white12,
                margin: EdgeInsets.symmetric(vertical: 4, horizontal: 25),
                child: Padding(
                  padding: EdgeInsets.all(7),
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        height: 15,
                      ),
                      Icon(
                        Icons.call,
                        color: Colors.redAccent,
                        size: 30,
                      ),
                      SizedBox(
                        width: 25,
                      ),
                      Text(
                        '8989691469',
                        style: TextStyle(
                          color: Colors.redAccent,
                          fontSize: 17,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                color: Colors.white12,
                margin: EdgeInsets.symmetric(
                  vertical: 10,
                  horizontal: 25,
                ),
                child: Padding(
                  padding: EdgeInsets.all(9),
                  child: Row(
                    children: <Widget>[
                      SizedBox(),
                      Icon(
                        Icons.email,
                        color: Colors.tealAccent,
                        size: 30,
                      ),
                      SizedBox(
                        width: 25,
                      ),
                      Text(
                        'pulkitdikshit8@gmail.com',
                        style: TextStyle(
                          fontSize: 17,
                          color: Colors.teal,
                          letterSpacing: 1,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Card(
                color: Colors.white12,
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                child: ListTile(
                  leading: Icon(
                    Icons.phone_android,
                    color: Colors.redAccent,
                    size: 25,
                  ),
                  title: Text(
                    'Pixel 2 XL',
                    style: TextStyle(
                        fontSize: 16,
                        letterSpacing: 1,
                        color: Colors.greenAccent,
                        fontFamily: 'CourierPrime'),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.symmetric(vertical: 10,horizontal: 25),
                color: Colors.white12,
                child: ListTile(
                  leading: Icon(
                    Icons.fastfood,
                    color: Colors.yellowAccent,
                    size: 25,
                  ),
                  title: Text(
                    'Pizza Lover',
                    style: TextStyle(
                      fontFamily: 'Pacifico',
                      fontSize: 18,
                      color: Colors.yellowAccent.shade700,letterSpacing: 2
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
